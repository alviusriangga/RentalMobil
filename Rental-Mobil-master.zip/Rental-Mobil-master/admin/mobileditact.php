<?php
include('includes/config.php');
error_reporting(0);
$vehicletitle = $_POST['vehicletitle'];
$brand = $_POST['brandname'];
$nopol = $_POST['nopol'];
$vehicleoverview = $_POST['vehicalorcview'];
$priceperday = $_POST['priceperday'];
$fueltype = $_POST['fueltype'];
$modelyear = $_POST['modelyear'];
$seatingcapacity = $_POST['seatingcapacity'];
$airconditioner = $_POST['airconditioner'];
$powerdoorlocks = $_POST['powerdoorlocks'];
$antilockbrakingsys = $_POST['antilockbrakingsys'];
$brakeassist = $_POST['brakeassist'];
$powersteering = $_POST['powersteering'];
$driverairbag = $_POST['driverairbag'];
$passengerairbag = $_POST['passengerairbag'];
$powerwindow = $_POST['powerwindow'];
$cdplayer = $_POST['cdplayer'];
$centrallocking = $_POST['centrallocking'];
$crashcensor = $_POST['crashcensor'];
$leatherseats = $_POST['leatherseats'];
$id = $_POST['id'];

$sql = "UPDATE mobil SET nama_mobil='$vehicletitle',nopol='$nopol',id_merek='$brand',deskripsi='$vehicleoverview',harga='$priceperday',bb='$fueltype',tahun='$modelyear',
	seating='$seatingcapacity',AirConditioner='$airconditioner',PowerDoorLocks='$powerdoorlocks',AntiLockBrakingSystem='$antilockbrakingsys',
	BrakeAssist='$brakeassist',PowerSteering='$powersteering',DriverAirbag='$driverairbag',PassengerAirbag='$passengerairbag',PowerWindows='$powerwindow',
	CDPlayer='$cdplayer',CentralLocking='$centrallocking',CrashSensor='$crashcensor',LeatherSeats='$leatherseats' where id_mobil='$id'";
$query 	= mysqli_query($koneksidb, $sql);
if ($query) {
	echo "<script type='text/javascript'>
			alert('Berhasil edit data.'); 
			document.location = 'mobil.php'; 
		</script>";
} else {
	echo "No Error : " . mysqli_errno($koneksidb);
	echo "<br/>";
	echo "Pesan Error : " . mysqli_error($koneksidb);

	echo "<script type='text/javascript'>
			alert('Terjadi kesalahan, silahkan coba lagi!.'); 
			document.location = 'mobiledit.php?id=$id'; 
		</script>";
}
